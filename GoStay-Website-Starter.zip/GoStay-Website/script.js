const tabs = document.querySelectorAll('.category-tab');
const cards = document.querySelectorAll('.experience-card');
const experience = document.getElementById('experience');
const destination = document.getElementById('destination');
const hint = document.getElementById('searchHint');

function filterCards(category = 'all', place = '') {
  let visible = 0;
  cards.forEach(card => {
    const categoryMatch = category === 'all' || card.dataset.category === category;
    const placeMatch = !place || card.dataset.place.includes(place) || place.includes(card.dataset.place);
    const show = categoryMatch && placeMatch;
    card.hidden = !show;
    if (show) visible++;
  });
  hint.textContent = visible
    ? `${visible} preview ${visible === 1 ? 'idea' : 'ideas'} found. Real provider listings will be added as GoStay grows.`
    : 'No preview cards match those filters yet. Try another category or destination.';
}

function activateTab(category) {
  tabs.forEach(tab => {
    const active = tab.dataset.category === category;
    tab.classList.toggle('active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  experience.value = category;
  filterCards(category, destination.value.trim().toLowerCase());
}

tabs.forEach(tab => tab.addEventListener('click', () => activateTab(tab.dataset.category)));
document.getElementById('searchForm').addEventListener('submit', event => {
  event.preventDefault();
  const category = experience.value;
  tabs.forEach(tab => {
    const active = tab.dataset.category === category;
    tab.classList.toggle('active', active);
    tab.setAttribute('aria-selected', String(active));
  });
  filterCards(category, destination.value.trim().toLowerCase());
  document.getElementById('experiences').scrollIntoView({behavior:'smooth'});
});
document.getElementById('clearFilters').addEventListener('click', () => {
  destination.value = '';
  experience.value = 'all';
  document.getElementById('date').value = '';
  activateTab('all');
});
document.querySelectorAll('[data-jump]').forEach(link => link.addEventListener('click', () => activateTab(link.dataset.jump)));
document.querySelectorAll('.heart').forEach(button => button.addEventListener('click', () => {
  button.classList.toggle('saved');
  button.textContent = button.classList.contains('saved') ? '♥' : '♡';
}));
const menu = document.querySelector('.menu-toggle');
menu.addEventListener('click', () => {
  const nav = document.querySelector('.main-nav');
  const open = nav.classList.toggle('open');
  menu.setAttribute('aria-expanded', String(open));
});
document.querySelectorAll('.main-nav a').forEach(link => link.addEventListener('click', () => {
  document.querySelector('.main-nav').classList.remove('open');
  menu.setAttribute('aria-expanded','false');
}));
document.getElementById('year').textContent = new Date().getFullYear();
