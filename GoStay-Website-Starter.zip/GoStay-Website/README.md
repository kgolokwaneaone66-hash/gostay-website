# GoStay website starter

A responsive front-end homepage concept for GoStay: accommodation, events, picnics, safari, hiking and other experiences.

## Preview
Open `index.html` in a browser. The page uses remote Unsplash photography and Google Fonts, so an internet connection is needed for those images/fonts.

## Publish
Upload `index.html`, `styles.css`, and `script.js` together to your hosting provider. Keep the three files in the same folder.

## Important
This is a front-end design prototype, not a complete booking platform. Search filters the sample preview cards. It does not yet create customer accounts, store listings, confirm bookings, process payments, or send website messages. Those features need a backend/database, provider dashboard, authentication, and a booking workflow. Replace the sample preview cards with verified provider listings before launch.

Contact details currently shown:
- Email: gostaybotswana@gmail.com
- WhatsApp: +267 75802584
