GOSTAY AI LAUNCH PACKAGE — START HERE

WHAT IS INCLUDED
1. GoStay_Website.html — responsive website, host listing submission demo with photos, a local Admin Review queue (approve/reject/unpublish), and a floating GoStay assistant.
2. config.js — public settings for the AI endpoint and official support email.
3. cloudflare-worker.js — secure backend starter. It keeps the OpenAI API key on the server, not in the public website.
4. This guide.

PHOTOS / VIDEOS
The host dashboard supports selecting up to 8 photos and 3 short videos and previewing them on the device. In this prototype, selecting media does NOT upload it to a server, save it to a shared host account, or publish a listing. A real listing portal needs authentication, file storage, file-size/type validation, moderation and a database.

BROWSER SUPPORT
The page uses standard responsive HTML/CSS/JavaScript and is designed to work in modern mobile and desktop browsers: Android Chrome, iPhone/iPad Safari, Microsoft Edge, Chrome and Firefox on Windows/macOS. It needs internet access for hosted deployment and external integrations. Test on real devices before launch.

AI CHAT
Without a backend endpoint, the chat uses limited built-in preview answers; it is NOT a live generative AI service. To enable live AI:
1. Create/sign in to a Cloudflare account and create a Worker.
2. Deploy cloudflare-worker.js (or paste it into the Worker editor).
3. Add OPENAI_API_KEY as a Worker secret; do not paste it into HTML or config.js. Add ALLOWED_ORIGIN as the exact published website origin after deploying, and optionally OPENAI_MODEL.
4. Deploy the Worker and test https://YOUR-WORKER.workers.dev/health .
5. Edit config.js: set aiEndpoint to https://YOUR-WORKER.workers.dev/api/chat . Set supportEmail after you create/confirm the official GoStay email address.
6. Upload the website HTML and config.js together to hosting. Test the chatbot and monitor usage/costs. Add rate limiting and a privacy notice before public use.

EMAIL
No email account has been created by this package. Choose and create the official GoStay support mailbox first (for example through a provider you control). Then enter the exact address in config.js supportEmail. The Email GoStay button opens the visitor's email app; to send and store web-form messages automatically, integrate a trusted email service or backend and configure it securely.

WHATSAPP
The website's existing WhatsApp links open the official enquiry number +267 75802584. They do not automatically reply with AI. To enable automated WhatsApp replies, register/configure the WhatsApp Business Platform with Meta, get the phone number ID and access token, configure a public webhook and verify token, subscribe to messages, and add the WhatsApp send-message webhook handler in the backend. The included Worker currently implements the website AI endpoint only; WhatsApp automation is NOT included as a live feature. Do not migrate your current number until you understand the account/coexistence options and test the setup.

BEFORE PUBLISHING
- This is a launch prototype, not a production booking platform.
- The Admin Review flow is a local demonstration only. It is not secure and does not provide real multi-user publishing. No real user accounts, shared database, permanent photo/video storage, verified live inventory, payment processing or booking confirmation is implemented.
- Keep secrets server-side. Never request card PINs, mobile-money PINs, passwords or card security codes in chat.
- Confirm legal/privacy requirements, secure hosting, backups, abuse controls and support procedures before public launch.
