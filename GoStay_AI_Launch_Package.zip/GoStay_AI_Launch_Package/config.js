// GoStay public website configuration. Never place API secrets in this file.
// Add this file to the HTML page before the main inline script if using custom hosting.
window.GOSTAY_CONFIG = {
  aiEndpoint: "", // e.g. https://YOUR-WORKER.workers.dev/api/chat after deploying the secure Worker
  supportEmail: "" // enter your official GoStay support email after creating it
};
