# GoStay website prototype — version 2

Responsive GoStay homepage with accommodation, events, picnics, safari and activities, plus front-end booking-request, provider-listing and account-interface previews.

## Files
- `index.html` — page structure and content
- `styles.css` — responsive visual design
- `script.js` — category filters, modal forms and demo interactions

## Preview
Open `index.html` in a browser. Internet access is needed for remote photography and Google Fonts.

## Important: prototype, not live booking infrastructure
This version demonstrates the customer and provider journeys. Sample booking requests and provider submissions are saved only in the visitor's own browser using local storage. They are NOT sent to GoStay, shared with other devices, or visible to administrators. Sign-in is a visual preview only. No customer account, real listing upload, booking confirmation, provider dashboard, messaging, or payment processing is active.

Before public launch, connect a secure backend/database and authentication system. Add role-based customer/provider/admin accounts, private photo storage, listing moderation, availability/calendar management, booking status and notifications, and payment integration. Use a trusted payment provider and never store card details directly. Configure privacy, terms, cancellation and provider agreements before taking bookings.

## Publish
Upload all three site files (`index.html`, `styles.css`, `script.js`) into the same hosting folder. Do not upload only the HTML file.
